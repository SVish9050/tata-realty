import express from 'express';
const router = express.Router();

router.get('/', (req, res) => {
    const baseUrl = req.protocol + '://' + req.headers.host + '/';
    res.render('Index', { url: baseUrl });
});

router.get('/login', (req, res) => {
    const baseUrl = req.protocol + '://' + req.headers.host + '/';
    res.render('Login', { url: baseUrl });
});

router.get('/signup', (req, res)=>{
    const baseUrl = req.protocol + '://' + req.headers.host + '/';
    res.render('Signup', { url: baseUrl });
});



export default router;